<?xml version="1.0" encoding="UTF-8"?>
<!--
	Bobert13's 2xBRm level 2 shader
	Based on Hyllian's xBR Shaders

	Copyright (C) 2011-2015 Hyllian/Jararaca - sergiogdb@gmail.com

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	THE SOFTWARE.
-->

<shader language="GLSL">
<vertex><![CDATA[
	uniform vec2 rubyTextureSize;
	attribute vec2 aPosition;
	attribute vec2 aTexCoord;
	varying vec4 vTexCoord[2];

	void main() {
		vec2 vPixel = 1.0 / rubyTextureSize;

		vTexCoord[0] = vec4(aTexCoord, aTexCoord + vPixel);
		vTexCoord[1] = vec4(aTexCoord, aTexCoord - vPixel);

		gl_Position = vec4(aPosition, 0.0, 1.0);
	}
]]></vertex>

<fragment filter="nearest" output_width="200%" output_height="200%"><![CDATA[
	//#define DEBUG
	//#define DEBUG_LV0
	#define LV2
	precision mediump float;
	uniform vec2 rubyTextureSize;
	uniform sampler2D rubyTexture;
	varying vec4 vTexCoord[2];
	const float eqThreshold = 0.025;
	const vec3 lumaCoef = vec3(0.299, 0.587, 0.114);

	vec4 RGBtoY(vec3 a, vec3 b, vec3 c , vec3 d) {
		vec4 Y = vec4(dot(a, lumaCoef), dot(b, lumaCoef), dot(c, lumaCoef), dot(d, lumaCoef));
		return Y;
	}

	vec4 DF(vec4 a, vec4 b)
		{return abs(a - b);}

	vec4 EQ(vec4 val)
		{return step(val, vec4(eqThreshold));}

	vec4 nEQ(vec4 val)
		{return step(vec4(eqThreshold), val);
	}
	void main() {
		vec4 vPos = vTexCoord[0]; //(0x,0y,+1x,+1y)
		vec4 vNeg = vTexCoord[1]; //(0x,0y,-1x,-1y)

		vec3 E = texture2D(rubyTexture, vPos.xy).xyz;
		vec3 color = E;

		vec3 B = texture2D(rubyTexture, vNeg.xw).xyz;
		vec3 D = texture2D(rubyTexture, vNeg.zy).xyz;
		vec3 F = texture2D(rubyTexture, vPos.zy).xyz;
		vec3 H = texture2D(rubyTexture, vPos.xw).xyz;

		vec4 e = RGBtoY(E, E, E, E);
		vec4 f = RGBtoY(F, H, D, B);

		vec3 A = texture2D(rubyTexture, vNeg.zw).xyz;
		vec3 C = texture2D(rubyTexture, vec2(vPos.z, vNeg.w)).xyz;
		vec3 I = texture2D(rubyTexture, vPos.zw).xyz;
		vec3 G = texture2D(rubyTexture, vec2(vNeg.z, vPos.w)).xyz;

		vec4 e_f = DF(e, f);
		vec4 e_h = e_f.yzwx;
		vec4 f_h = DF(f, f.yzwx);
		vec4 h_d = f_h.yzwx;
		vec4 d_b = f_h.zwxy;
		vec4 b_f = f_h.wxyz;

		vec4 check = (nEQ(e_f) * nEQ(e_h));
		if(dot(check, step(vec4(2.0) * f_h, e_f + e_h)) > 0.0)
		{
		#ifdef DEBUG_LV0
			color = vec3(1.0, 0.0, 0.0);
		#endif
			vec4 i = RGBtoY(I, G, A, C);
			vec4 e_i = DF(e, i); vec4 e_g = e_i.yzwx; vec4 e_c = e_i.wxyz; vec4 e_a = e_i.zwxy;
			vec4 g_h = DF(i, f).yzwx;
			vec4 c_f = DF(i, f.yzwx).wxyz;

			vec4 mask = vec4(1.0, 0.0, 0.0, 0.0);
			vec4 maskL = vec4(0.0, 0.0, 0.0, 0.5);
			vec4 maskU = vec4(0.0, 0.5, 0.0, 0.0);
			vec2 iRotation = step(0.5, fract(vPos.xy * rubyTextureSize));
			if (iRotation.x != iRotation.y) // rotate
			{
				mask = mask.wxyz, maskU = maskU.wxyz, maskL = maskL.wxyz;
				vec3 Z = F;
				F = H, H = D, D = B, B = Z;
			}
			if (iRotation.y == 0.0) // flip-flop
			{
				mask = mask.zwxy, maskU = maskU.zwxy, maskL = maskL.zwxy;
				F = D, H = B;
			}

			vec4 neg = e_i + h_d + b_f;
			vec4 pos = f_h + e_g + e_c;
			vec4 localContrast = 1.0 - step(neg, pos);
			vec4 lv0 = check * localContrast;

			vec4 left1 = step(vec4(2.0) * e_g, e_h + g_h);
			vec4 up1   = step(vec4(2.0) * e_c, e_f + c_f);
			vec4 lv1 = clamp(left1 + up1, 0.0, 1.0);
			vec4 blend = mask * lv1;

			vec4 left2 = maskL * up1   * step(vec4(2.0) * g_h, e_g + e_h);
			vec4 up2   = maskU * left1 * step(vec4(2.0) * c_f, e_c + e_f);
			vec4 blend2 = left2 + up2;

			blend = clamp(blend + blend2, 0.0, 1.0) * lv0;
			float strength = max(max(blend.x, blend.y), max(blend.z, blend.w));

			float pick = strength - 0.5;
			vec4 top = step(vec4(strength), blend);
			pick = pick + dot(left2, top) * 2.0;

		#ifdef DEBUG
			if (strength < 1.0 && strength > 0.01)
				{color = vec3(1.0, 0.0, 0.0);}
			else
				{color = mix(color, vec3(0.0, 1.0, 0.0), strength);}
		#else
			strength = min(0.75 * strength, 0.5); // strength = 0.5 for a lv1 blend and 0.375 for a lv2
			color = mix(sqrt(E), mix(sqrt(H), sqrt(F), pick), strength);
			color = color * color;
		#endif
		}
		gl_FragColor.rgb = color;
	}
]]></fragment>
</shader>