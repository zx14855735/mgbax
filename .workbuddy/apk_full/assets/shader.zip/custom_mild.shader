<?xml version="1.0" encoding="UTF-8"?>
<shader language="GLSL">
<vertex>
<![CDATA[
attribute vec2 a_vertex_coordinate;
attribute vec2 a_texture_coordinate;
uniform vec4 u_texture_size;
varying vec2 v_texture_coordinate;

void main(){
gl_Position = vec4(a_vertex_coordinate.xy, 0.0, 1.0);
v_texture_coordinate = a_texture_coordinate; } ]]>
</vertex>

<fragment filter="nearest" output_width="600%" output_height="600%">
<![CDATA[
#if GL_ES
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
#endif
#define r 0.83
#define g 0.65
#define b 0.765
#define rg 0.105
#define rb 0.105
#define gr 0.20
#define gb 0.13
#define br -0.03
#define bg 0.245
uniform sampler2D u_texture;
uniform vec4 u_texture_size;
varying vec2 v_texture_coordinate;

void main(){
vec3 screen = pow(texture2D(u_texture, v_texture_coordinate.xy).rgb, vec3(1.0));
screen = clamp(screen, 0.0, 1.0);
screen = pow(mat3(r, rg, rb,gr, g, gb, br, bg, b) * screen, vec3(1.0));
gl_FragColor = vec4(screen, 1.0); } ]]>
</fragment>
</shader>