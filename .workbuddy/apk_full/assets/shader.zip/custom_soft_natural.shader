<?xml version="1.0" encoding="UTF-8"?>
<shader language="GLSL">
<vertex><![CDATA[

attribute vec2 a_vertex_coordinate;
attribute vec2 a_texcoord;
uniform vec4 u_texture_size;
varying vec4 v_texcoord;
varying vec4 v_texcoord1;
varying vec4 v_texcoord2;
varying vec4 v_texcoord3;
varying vec4 v_texcoord4;
varying vec4 v_texcoord5;
varying vec4 v_texcoord6;
varying vec4 v_texcoord7;
varying vec4 v_texcoord8;

void main(){
float x=u_texture_size.x+0.0015;
float y=u_texture_size.y-0.0015;
gl_Position=vec4(a_vertex_coordinate.xy,0.0,1.0);
vec2 a=vec2(x,y);
vec2 b=vec2(-x,y);
vec2 c=vec2(x,-y);
vec2 d=vec2(-x,-y);
v_texcoord=a_texcoord.xyxy;
v_texcoord1.xy=v_texcoord.xy+a;
v_texcoord2.xy=v_texcoord.xy+a;
v_texcoord3.xy=v_texcoord.xy+b;
v_texcoord4.xy=v_texcoord.xy+b;
v_texcoord5.xy=v_texcoord.xy+c;
v_texcoord6.xy=v_texcoord.xy+c;
v_texcoord7.xy=v_texcoord.xy+d;
v_texcoord8.xy=v_texcoord.xy+d; }

]]></vertex>

<fragment filter="nearest" output_width="600%" output_height="600%"><![CDATA[
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform sampler2D sampler0;
varying vec4 v_texcoord;
varying vec4 v_texcoord1;
varying vec4 v_texcoord2;
varying vec4 v_texcoord3;
varying vec4 v_texcoord4;
varying vec4 v_texcoord5;
varying vec4 v_texcoord6;
varying vec4 v_texcoord7;
varying vec4 v_texcoord8;
const mat3 RGBtoYIQ=mat3(0.299,0.596,0.212,0.587,-0.275,-0.523,0.114,-0.321,0.311);
const mat3 YIQtoRGB=mat3(1.0,1.0,1.0,0.95568806036115671171,-0.27158179694405859326,-1.1081773266826619523,0.61985809445637075388,-0.64687381613840131330,1.7050645599191817149);

void main(){
vec3 a0=texture2D(sampler0,v_texcoord.xy).rgb;
vec3 a1=texture2D(sampler0,v_texcoord1.xy).rgb;
vec3 a2=texture2D(sampler0,v_texcoord2.xy).rgb;
vec3 a3=texture2D(sampler0,v_texcoord3.xy).rgb;
vec3 a4=texture2D(sampler0,v_texcoord4.xy).rgb;
vec3 a5=texture2D(sampler0,v_texcoord5.xy).rgb;
vec3 a6=texture2D(sampler0,v_texcoord6.xy).rgb;
vec3 a7=texture2D(sampler0,v_texcoord7.xy).rgb;
vec3 a8=texture2D(sampler0,v_texcoord8.xy).rgb;
vec3 dt=vec3(1.25,1.25,1.25);
float c1=dot(abs(a1-a0),dt)+0.1;
float c2=dot(abs(a2-a0),dt)+0.1;
float c3=dot(abs(a3-a0),dt)+0.1;
float c4=dot(abs(a4-a0),dt)+0.1;
float c5=dot(abs(a5-a0),dt)+0.1;
float c6=dot(abs(a6-a0),dt)+0.1;
float c7=dot(abs(a7-a0),dt)+0.1;
float c8=dot(abs(a8-a0),dt)+0.1;
float aa=c1+c2+c3+c4+c5+c6+c7+c8;
a0=RGBtoYIQ*(c8*a1+c7*a2+c6*a3+c5*a4+c4*a5+c3*a6+c2*a7+c1*a8+a0*0.01)/aa;
a0=vec3(pow(a0.x,dt.x),a0.yz*dt.yz);
vec4 natural;
natural.xyz=1.15*YIQtoRGB*a0;
vec4 rgb32=natural;
gl_FragColor=rgb32; }

]]></fragment>
</shader>
