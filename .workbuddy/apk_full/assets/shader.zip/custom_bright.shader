<?xml version="1.0" encoding="UTF-8"?>
<shader language="GLSL">
<vertex><![CDATA[
uniform vec2 rubyTextureSize;
uniform vec2 rubyInputSize;
uniform vec2 rubyOutputSize;
attribute vec2 aPosition;
attribute vec2 aTexCoord;
varying vec2 vTexCoord;
varying vec2 omega;

void main(){
gl_Position = vec4(aPosition, 0.0, 1.0);
vTexCoord = aTexCoord;
omega = vec2(0,0); } ]]>
</vertex>

<fragment filter="nearest" output_width="600%" output_height="600%">
<![CDATA[
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

uniform sampler2D rubyTexture;
varying vec2 vTexCoord;
varying vec2 omega;
const vec2 sine_comp = vec2(0,0);

void main(){
vec4 c11 = texture2D(rubyTexture, vTexCoord);
vec4 scanline = c11 * (1.15 + dot(sine_comp * sin(vTexCoord * omega), vec2(1.0)));
gl_FragColor = clamp(scanline, 0.0, 1.0); } ]]>
</fragment>
</shader>