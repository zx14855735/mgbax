<?xml version="1.0" encoding="UTF-8"?>
<!--
   Author: Gigaherz
   License: Public domain
-->

<shader language="GLSL">
<vertex><![CDATA[
  uniform vec2 rubyTextureSize;
  attribute vec2 aPosition;
  attribute vec2 aTexCoord;


  varying vec2 v_texture_coordinate;
  varying vec4 v_texture_coordinate_1;
  varying vec4 v_texture_coordinate_2;
  varying vec4 v_texture_coordinate_3;
  varying vec4 v_texture_coordinate_4;

  varying vec2 pixel_no;




  void main()
  {
    
    
    vec2 dx = vec2(rubyTextureSize.x, 0.0);
    vec2 dy = vec2(0.0, rubyTextureSize.y);
    gl_Position = vec4(aPosition, 0.0, 1.0);
    v_texture_coordinate = aTexCoord;
    v_texture_coordinate_1.xy = v_texture_coordinate.xy - dx - dy;
    v_texture_coordinate_1.zw = v_texture_coordinate.xy - dy;
    v_texture_coordinate_2.xy = v_texture_coordinate.xy + dx - dy;
    v_texture_coordinate_2.zw = v_texture_coordinate.xy - dx;
    v_texture_coordinate_3.xy = v_texture_coordinate.xy + dx;
    v_texture_coordinate_3.zw = v_texture_coordinate.xy - dx + dy;
    v_texture_coordinate_4.xy = v_texture_coordinate.xy + dy;
    v_texture_coordinate_4.zw = v_texture_coordinate.xy + dx + dy;
    pixel_no = v_texture_coordinate * rubyTextureSize ;
  }
]]></vertex>

<fragment  output_width="1350%" output_height="1350%"><![CDATA[
  #ifdef GL_FRAGMENT_PRECISION_HIGH
  precision highp float;
  #else
  precision mediump float;
  #endif
  uniform sampler2D rubyTexture;
  uniform vec2 rubyTextureSize;

  varying vec2 v_texture_coordinate;
  varying vec4 v_texture_coordinate_1;
  varying vec4 v_texture_coordinate_2;
  varying vec4 v_texture_coordinate_3;
  varying vec4 v_texture_coordinate_4;

  varying vec2 pixel_no;


  const float gamma = 2.0;
  const float shine = 0.05;
  const float blend = 0.65;

  float dist(vec2 coord, vec2 source)
  {
    vec2 delta = coord - source;
    return sqrt(dot(delta, delta));
  }

  float color_bloom(vec3 color)
  {
    const vec3 gray_coeff = vec3(0.30, 0.59, 0.11);
    float bright = dot(color, gray_coeff);
    return mix(1.0 + shine, 1.0 - shine, bright);
  }

  vec3 lookup(vec2 pixel_no, float offset_x, float offset_y, vec3 color)
  {
    vec2 offset = vec2(offset_x, offset_y);
    float delta = dist(fract(pixel_no), offset + vec2(0.5, 0.5));
    return color * exp(-gamma * delta * color_bloom(color));
  }

  void main()
  {
    vec3 c00 = texture2D(rubyTexture, v_texture_coordinate_1.xy).rgb;
    vec3 c10 = texture2D(rubyTexture, v_texture_coordinate_1.zw).rgb;
    vec3 c20 = texture2D(rubyTexture, v_texture_coordinate_2.xy).rgb;
    vec3 c01 = texture2D(rubyTexture, v_texture_coordinate_2.zw).rgb;
    vec3 c11 = texture2D(rubyTexture, v_texture_coordinate.xy).rgb;
    vec3 c21 = texture2D(rubyTexture, v_texture_coordinate_3.xy).rgb;
    vec3 c02 = texture2D(rubyTexture, v_texture_coordinate_3.zw).rgb;
    vec3 c12 = texture2D(rubyTexture, v_texture_coordinate_4.xy).rgb;
    vec3 c22 = texture2D(rubyTexture, v_texture_coordinate_4.zw).rgb;
    
    vec3 mid_color = lookup(pixel_no, 0.0, 0.0, c11);
    vec3 color = vec3(0.0, 0.0, 0.0);
    color += lookup(pixel_no, 0.0, -1.0, c10);
    color += lookup(pixel_no, -1.0, 0.0, c01);
    color += mid_color;
    color += lookup(pixel_no, 1.0, 0.0, c21);
    color += lookup(pixel_no, 0.0, 1.0, c12);
    gl_FragColor.rgb = mix(1.2 * mid_color, color, blend);
    gl_FragColor.a = 1.0;
  }
]]></fragment>
</shader>
